##' Design a PLS-DA model
##'
##' This function is based on a \code{opls} function
##' @param x data matrix
##' @param y outcome
##' @param ... additional parameters, currently not used
##' @return A fitted model
##' @author Eva Freyhult
##' @import ropls
##' @aliases fit_plsda
##' @export
fit_plsda <- function(x, y, ...) {
  f <- try(opls(x, y, fig.pdfC="none", info.txtC="none", permI=0), silent=TRUE) #, predI=min(10,ncol(x)), permI=0)
  ##At least two latent variables
  if (inherits(f, "try-error")) {
    if (ncol(x)>1) {
      f <- opls(x, y, fig.pdfC="none", info.txtC="none", permI=0, predI=2)
    } else if (ncol(x)==1) {
      f <- opls(x, y, fig.pdfC="none", info.txtC="none", permI=0, predI=1)
    }
  } else if (ncol(x)>1 & ncol(f@loadingMN)<2) {
    f <- opls(x, y, fig.pdfC="none", info.txtC="none", permI=0, predI=2)
  }
  return(f)
}

##' Predict PLS-DA model
##'
##' @param object The fited model
##' @param x The new data to predict output for
##' @param ... Additional parameters, currently not used
##' @return The prediction, probability and scores
##' @author Eva Freyhult
##' @import ropls
##' @aliases predict_plsda
##' @export
predict_plsda <- function(object, x, ...) {
  xteMN <- scale(as.matrix(x), object@xMeanVn, object@xSdVn)
  xscoresMN <-  xteMN %*% object@weightStarMN
  yTesScaMN <- xteMN %*% object@coefficientMN
  yTesMN <- scale(scale(yTesScaMN, FALSE, 1/object@ySdVn), -object@yMeanVn, FALSE)
  yTestMCN <- object@suppLs$.char2numF(yTesMN,c2nL = FALSE)
  if (length(levels(object@suppLs$y))==2)
    return(data.frame(prediction = factor(yTestMCN[,1], levels=levels(object@suppLs$y)),
                      probability = yTesMN[,1],
                      scores = xscoresMN))
  else
    return(data.frame(prediction = factor(yTestMCN, levels=levels(object@suppLs$y)),
                      probability=yTesMN,
                      scores = xscoresMN))
}


#' Perform holdout procedure with PLS-DA
#'
#' @param X Input data matrix
#' @param Y Outcome vector
#' @param holdouts The holdouts
#' @return A list of pred (predcitions), VIP and fit0 (fit based on all data)
#' @author Eva Freyhult
#' @import tidyverse
#' @export
hoPLSDA <- function(X, Y, holdouts=index_crossval(Y, 5, 10)) {
  id <- rownames(X)
  fit0 <- fit_plsda(X, Y)
  pred <- predict_plsda(fit0, X)
  pred <- pred %>% transmute(id=id, Y=Y, h=0, holdout=FALSE, pred=prediction, lpred=probability, p1=scores.p1, p2=scores.p2)
  vip <- data.frame(var=names(fit0@vipVn), vip=fit0@vipVn, h=0)
  n <- ncol(holdouts)
  fits <- lapply(1:n, function(h) fit_plsda(X[!holdouts[[h]], ], Y[!holdouts[[h]]]))
  vip <- rbind(vip, do.call("rbind", lapply(1:n, function(h) data.frame(var=names(fits[[h]]@vipVn), vip=fits[[h]]@vipVn, h=h))))
  pred <- rbind(pred, do.call("rbind", lapply(1:n, function(h) {
    pred <- predict_plsda(fits[[h]], X)
    pred$holdout <- holdouts[[h]]
    pred %>% transmute(id=id, Y=Y, h=h, holdout=holdout, pred=prediction, lpred=probability, p1=scores.p1, p2=scores.p2)
  })))
  list(pred=pred, vip=vip, fit0=fit0)
}
