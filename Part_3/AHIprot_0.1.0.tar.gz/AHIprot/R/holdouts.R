##' Generate crossvalidation indices
##'
##' @param y The outcome (vector or Surv object)
##' @param nfold Number of folds
##' @param nrep Number of repeats
##' @param balanced Should the cross validation be balanced with
##'     respect to y?
##' @param subset subset indices (default TRUE)
##' @return A matrix with each column describing a test set (as a
##'     binary vector, TRUE indicating a sample included in the test
##'     set)
##' @author Eva Freyhult
##' @export
##' @import survival
index_crossval <- function(y, nfold, nrep, balanced=is.factor(y), subset=TRUE) {
  sample1 <- function(x, ...) x[sample.int(length(x), ...)]

  ny <- length(y)
  idx <- (1:length(y))[subset]
  n <- length(idx)
  ## Number missing to same number of samples in every fold
  nmiss <- ceiling(n/nfold)*nfold - n
  folds <- do.call("cbind", replicate(nrep, {if (!balanced) {
    ind <- sample1(idx)
  } else {
    levs <- if(is.factor(y)) levels(y) else unique(y)
    ind <- do.call("c", lapply(levs, function(l) {
      i <- idx[y[idx]==l]
      sample1(i)
    }))
  }
    ind <- matrix(c(ind, rep(NA,nmiss)), byrow=TRUE, ncol=nfold)
    ind <- apply(ind, 2, function(i) 1:ny %in% i)
  }, simplify=FALSE))
  folds <- as.data.frame(folds)
  names(folds) <- sprintf("rep%ifold%i", rep(1:nrep,each = nfold), rep(1:nfold, nrep))
  return(folds)
}
