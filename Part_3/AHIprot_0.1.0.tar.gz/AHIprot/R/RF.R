### Random Forest ###

##' Design a RF (randomForest) model
##'
##' This function is based on the \code{randomForest} function
##' @param x data matrix
##' @param y outcome
##' @param importance Should VIMP be computed? (default is TRUE)
##' @param ... additional parameters, currently not used
##' @return A fitted model
##' @author Eva Freyhult
##' @import randomForest
##' @export
fit_RF <- function (x, y, importance=TRUE, ...)
{
  randomForest::randomForest(x, y, importance=importance, ...)
}

##' Predict RF (randomForest) model
##'
##' @param object The fited model
##' @param x The new data to predict output for
##' @param ... Additional parameters, currently not used
##' @return The prediction and probability
##' @author Eva Freyhult
##' @import randomForest
##' @export
predict_RF <- function (object, x, ...)
{
  if (is.factor(object$y)) {
    data.frame(prediction = predict(object, newdata = x, type = "response"),
               probability = predict(object, newdata = x, type = "prob")[,-1])
  }
  else {
    data.frame(prediction = predict(object, newdata = x, type = "response"))
  }
}

#' Perform holdout procedure with randomforest
#'
#' @param X Input data matrix
#' @param Y Outcome vector
#' @param holdouts The holdouts
#'
#' @return A list of pred (predcitions), VIP and fit0 (fit based on all data)
#' @author Eva Freyhult
#' @import tidyverse stats
#' @export
hoRF <- function(X, Y, holdouts=index_crossval(Y, 5, 10)) {
  id <- rownames(X)
  fit0 <- fit_RF(X, Y)
  pred <- predict_RF(fit0, X)
  pred <- pred %>% transmute(id=id, Y=Y, h=0, holdout=FALSE, pred=prediction, lpred=probability)
  vip <- data.frame(var=rownames(fit0$importance), vip=fit0$importance[, "MeanDecreaseAccuracy"], h=0)
  S0 <- data.frame(MDS=cmdscale(1 - predict(fit0, X, proximity=TRUE)$proximity, k=2), Y=Y, id=rownames(X))
  pred$p1 <- S0[,1]
  pred$p2 <- S0[,2]
  n <- ncol(holdouts)
  fits <- lapply(1:n, function(h) fit_RF(X[!holdouts[[h]], ], Y[!holdouts[[h]]]))
  vip <- rbind(vip, do.call("rbind", lapply(1:n, function(h) data.frame(var=rownames(fits[[h]]$importance), vip=fits[[h]]$importance[, "MeanDecreaseAccuracy"], h=h))))
  pred <- rbind(pred, do.call("rbind", lapply(1:n, function(h) {
    pred <- predict_RF(fits[[h]], X)
    pred$holdout <- holdouts[[h]]
    S <- data.frame(MDS=cmdscale(1 - predict(fits[[h]], X, proximity=TRUE)$proximity, k=2), Y=Y, id=rownames(X))
    pred %>% transmute(id=id, Y=Y, h=h, holdout=holdout, pred=prediction, lpred=probability, p1=S[,1], p2=S[,2])
  })))
  list(pred=pred, vip=vip, fit0=fit0)
}
