#' Find optimal boxcox transformation
#'
#' @param df data set
#' @param x
#' @param y
#' @param subjid
#'
#' @return
#' @export
#'
#' @import MASS
boxcoxlambda <- function(df, x="day", y="vload", subjid="subjid") {
  df <- df %>% rename(x=!!as.symbol(x), y=!!as.symbol(y), subjid=!!as.symbol(subjid))
  bcy<-boxcox(y~x+subjid, lambda=seq(-2,2,0.5), interp=FALSE, data=df, plotit=FALSE)
  bcx<-boxcox(x+1~subjid, lambda=seq(-2,2,0.5), interp=FALSE, data=df, plotit=FALSE)
  lambday <- bcy$x[which.max(bcy$y)]
  lambdax <- bcx$x[which.max(bcx$y)]
  return(list(x=lambdax, y=lambday))
}

#' Transform data, find optimal spar and compute cubic smoothing spline for a set of subjects
#'
#' @param df data
#' @param time name of time variable
#' @param value name of value of interest
#' @param subjid name of variable defining subjects
#'
#' @author Eva Freyhult
#' @return A list
#' @import MASS
#' @export
splines <- function(df, time="day", value="vload", subjid="subjid", lambda) {
  pl <- list()

  ss <- function(df, s) {
    res <- sapply(1:nrow(df), function(i) {
      spl <- smooth.spline(df$x[-i], df$y[-i], spar=s)
      predict(spl, df$x[i])$y - df$y[i]
    })
    return(sum(res^2))
  }

  ## Transform
  if (missing(lambda))
    lambda <- boxcoxlambda(df, time, value, subjid)

  df <- df %>% group_by(!!as.symbol(subjid)) %>% mutate(time=!!as.symbol(time), value=!!as.symbol(value)) %>%
    arrange(time) %>%
    mutate(x=if (lambda$x==0) log10(time+1) else (time+1)^lambda$x,
           y=if (lambda$y==0) log10(value) else value^lambda$y)

  labs <- c(time, paste(time, "transform"), value, paste(value, "transform"))
  names(labs) <- c(time,"x", value, "y")
  Z <- df %>% ungroup() %>% dplyr::select(all_of(c(time, value, subjid)), x, y) %>% melt() %>%
    mutate(variable=factor(variable, levels=names(labs), labels=labs))
  pl$distr <- Z %>% ggplot(aes(x=value, fill=subjid)) + geom_histogram(bins=20) + facet_wrap(~variable, scales="free") + theme_bw() + theme(legend.position = "none")

  spar <- seq(0,1,0.01)
  ##When optimizing spar, no duplicate days for any subjid, use last value and only patients with 5 or more measurements
  dflast <- df %>% group_by(x, !!as.symbol(subjid)) %>% summarize(y=last(y), .groups="drop") %>% group_by(!!as.symbol(subjid)) %>% mutate(n=n()) %>% dplyr::filter(n>=5)
  ss <- sapply(spar, function(s) dflast %>% summarize(ss=ss(cur_data(), s), .groups="drop") %>% pull("ss") %>% sum())

  sparmin <- spar[which.min(ss)]
  pl$spar <- ggplot(data=data.frame(spar=spar, ss=ss), aes(x=spar, y=ss)) + geom_point()

  ##Observed days
  mnmx <- df %>% group_by(!!as.symbol(subjid)) %>% summarise(mn=min(time), mx=max(time))

  ##Days evenly spread on transformed-scale
  #d <- seq(0, sqrt(max(VL$day)), 0.1)^2
  xnew <- seq(min(df$x), max(df$x), length.out = 500)

  splinex <- df %>% group_by(!!as.symbol(subjid)) %>% arrange(x) %>%
    summarize(as.data.frame(predict(smooth.spline(x, y, spar=sparmin), x=xnew)), .groups="drop") %>%
    mutate(time=if (lambda$x==0) 10^x-1 else x^(1/lambda$x),
           value=if (lambda$y==0) 10^y-1 else y^(1/lambda$y))
  splinex <- splinex %>% left_join(mnmx)

  ##Exclude extrapolated values
  spline <- splinex %>% dplyr::filter(time>=mn&time<=mx)

  ##VL, log10, spline, wide
  splw <- spline %>% pivot_wider(names_from=subjid, values_from=y, id_cols=time) %>% arrange(time)
  splxw <- splinex %>% pivot_wider(names_from=subjid, values_from=y, id_cols=time) %>% arrange(time)

  return(list(spline=spline %>% rename(!!as.symbol(time) := time, !!as.symbol(value):=value),
              splinex=splinex %>% rename(!!as.symbol(time) := time, !!as.symbol(value):=value),
              splw=splw %>% rename(!!as.symbol(time) := time),
              splxw=splxw %>% rename(!!as.symbol(time) := time),
              lambda=lambda, pl=pl))
}

#' Complete linkage clustering using Euclidean clustering based on cubic smoothing spline for given time span
#'
#' @param splw spline matrix in wide format
#' @param splines splines, long format
#' @param lambda lambda for boxcox transformation for time and value
#' @param lmt time limits
#' @param time character string defining time variable
#' @param value character string defining value variable
#'
#' @return
#' @import factoextra NbClust pvclust
#' @export
Eucluster <- function(splw, spline, lambda, lmt, lmtnm, time="day", value="vload", pv=FALSE, alpha=0.90) {
  z <- splw %>% rename(time:=!!as.symbol(time)) %>% dplyr::filter(time>=lmt[1], time<=lmt[2]) %>% dplyr::select(which(colMeans(is.na(.))==0))
  ##Bootstrap p-values
  if (pv) {
    pvc <- pvclust(z[, -1], method.hclust = "complete", method.dist="euclidean", nboot=100, quiet=TRUE)
    cl <- pvpick(pvc, alpha=alpha)
    cl <- data.frame(subjid=unlist(cl$clusters), cl=rep(1:length(cl$clusters), sapply(cl$clusters, length)))
    pvpl <- spline %>% dplyr::filter((!!as.symbol(time))>=lmt[1], (!!as.symbol(time))<=lmt[2]) %>% left_join(cl) %>%
      dplyr::filter(subjid %in% colnames(z)) %>%
      ggplot(aes(x=(!!as.symbol(time)), y=(!!as.symbol(value)), group=subjid, color=ifelse(is.na(cl), NA, paste("Cluster ", cl)))) +
      geom_line() + theme_bw() + scale_color_discrete("", na.value="grey70") +
      ggtitle(sprintf("Time interval %s", lmtnm)) +
      scale_x_continuous(trans=scales::boxcox_trans(lambda$x, 1)) +
      scale_y_continuous(trans=scales::boxcox_trans(lambda$y))
  }
  ##Optimal number of clusters
  clopt <- NbClust(t(z[,-1]), distance="euclidean", method="complete", index ="silhouette", min.nc=2, max.nc=min(10, ncol(z)-2))
  h <- hclust(dist(t(z[,-1])))
  hpl <- fviz_dend(h, ylab="Distance", main=sprintf("Time interval %s", lmtnm), k=clopt$Best.nc['Number_clusters'])
  cl <- data.frame(subjid=names(clopt$Best.partition), cl=clopt$Best.partition)
  pl <- spline %>% dplyr::filter((!!as.symbol(time))>=lmt[1], (!!as.symbol(time))<=lmt[2]) %>% left_join(cl) %>%
    dplyr::filter(!is.na(cl)) %>%
    ggplot(aes(x=(!!as.symbol(time)), y=(!!as.symbol(value)), group=subjid, color=paste("Cluster ", cl))) +
    geom_line() + theme_bw() + scale_color_discrete("") +
    ggtitle(sprintf("Time interval %s", lmtnm)) +
    scale_x_continuous(trans=scales::boxcox_trans(lambda$x, 1)) +
    scale_y_continuous(trans=scales::boxcox_trans(lambda$y))
  if (pv)
    return(list(h=h, cl=cl, hpl=hpl, pl=pl, pvc=pvc, pvpl=pvpl))
  else
    return(list(h=h, cl=cl, hpl=hpl, pl=pl))
}

